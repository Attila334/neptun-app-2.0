package com.example.neptun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeptunApplicationTests {

	@Test
	void contextLoads() {
	}

}
